import xadmin
from .models import *

from datetime import datetime
from django.db import models
from orgs.models import OrgInfo, TeacherInfo


class CourseInfoXadmin(object):
    list_display = ['image', 'name', 'study_time', 'study_num', 'level', 'collect_num', 'click_num', 'desc', 'detail',
                    'category', 'course_notice', 'course_require', 'teaching', 'orginfo', 'teacherinfo', 'add_time']


class LessonInforXadmin(object):
    list_display = ['name', 'courseinfo', 'add_time']


class VideoInfoXadmin(object):
    list_display = ['name', 'study_time', 'url', 'lessoninfo', 'add_time']


class SourceInfoXadmin(object):
    list_display = ['name', 'download', 'courseinfo', 'add_time']


xadmin.site.register(CourseInfo, CourseInfoXadmin)
xadmin.site.register(LessonInfor, LessonInforXadmin)
xadmin.site.register(VideoInfo, VideoInfoXadmin)
xadmin.site.register(SourceInfo, SourceInfoXadmin)