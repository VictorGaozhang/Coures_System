import xadmin

from datetime import datetime
from django.db import models
from orgs.models import OrgInfo, TeacherInfo


# Create your models here.
class CourseInfo(models.Model):
    image = models.ImageField(upload_to='course/', max_length=200, verbose_name="Class Image")
    name = models.CharField(max_length=20, verbose_name="Class Name")
    study_time = models.IntegerField(default=0, verbose_name="Course Time")
    study_num = models.IntegerField(default=0, verbose_name="Learners Number")
    level = models.CharField(choices=(('gj', 'Profession'), ('zj', 'Deeper'), ('cj', 'New start')), max_length=5,
                             verbose_name="Course Level")
    collect_num = models.IntegerField(default=0, verbose_name="Collection Number")
    click_num = models.IntegerField(default=0, verbose_name="Visits Number")
    desc = models.CharField(max_length=20, verbose_name="Course Describe")
    detail = models.CharField(max_length=20, verbose_name="Course Details")
    category = models.CharField(choices=(('qd', 'Front-end'), ('hd', "Backend")), verbose_name="Course Type",
                                max_length=5)
    course_notice = models.CharField(max_length=200, verbose_name="Course Notification")
    course_require = models.CharField(max_length=100, verbose_name="Course Requirement")
    teaching = models.CharField(max_length=100, verbose_name="Teaching")
    orginfo = models.ForeignKey(OrgInfo, verbose_name="Affiliation", on_delete=models.CASCADE, )
    teacherinfo = models.ForeignKey(TeacherInfo, verbose_name="Teacher", on_delete=models.CASCADE, )
    is_banner = models.BooleanField(default=False, verbose_name="Restart or not")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Course Information'
        verbose_name_plural = verbose_name


class LessonInfor(models.Model):
    name = models.CharField(max_length=50, verbose_name="Lesson Name")
    courseinfo = models.ForeignKey(CourseInfo, verbose_name="Lesson", on_delete=models.CASCADE, )
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Lesson Information'
        verbose_name_plural = verbose_name


class VideoInfo(models.Model):
    name = models.CharField(max_length=50, verbose_name="Video Name")
    study_time = models.IntegerField(default=0, verbose_name="Video Time")
    url = models.URLField(default='http://www.google.com', verbose_name="Video URL", max_length=200)
    lessoninfo = models.ForeignKey(LessonInfor, verbose_name="Lesson", on_delete=models.CASCADE, )
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Video Information'
        verbose_name_plural = verbose_name


class SourceInfo(models.Model):
    name = models.CharField(max_length=50, verbose_name="Video Name")
    download = models.FileField(upload_to='source/', max_length=200, verbose_name="Download Path")
    courseinfo = models.ForeignKey(CourseInfo, verbose_name="lesson", on_delete=models.CASCADE, )
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Video Information'
        verbose_name_plural = verbose_name
