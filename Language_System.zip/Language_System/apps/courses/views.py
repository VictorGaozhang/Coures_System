from django.shortcuts import render
from .models import CourseInfo
from django.core.paginator import PageNotAnInteger, EmptyPage, Paginator
from operations.models import UserLike, UserCourse

# Create your views here.
def course_list(request):
    all_courses = CourseInfo.objects.all()
    recommed_courses = all_courses.order_by('-add_time')[:3]

    sort = request.GET.get('sort', '')
    if sort:
        all_courses = all_courses.order_by('-' + sort)

    pagenum = request.GET.get('pagenum', '')
    pa = Paginator(all_courses, 3)
    try:
        pages = pa.page(pagenum)
    except PageNotAnInteger:
        pages = pa.page(1)
    except EmptyPage:
        pages = pa.page(pa.num_pages)

    return render(request, 'courses/course-list.html', {
        'all_courses': all_courses,
        'pages': pages,
        'recommand_courses': recommed_courses,
        'sort': sort
    })


def course_detail(request, course_id):
    if course_id:
        course = CourseInfo.objects.filter(id = int(course_id))[0]
        relate_courses = CourseInfo.objects.filter(category=course.category).exclude(id=int(course_id))[:2]

        course.click_num += 1
        course.save()

        likecourse = False
        likeorg = False
        if request.user.is_authenticated():
            like = UserLike.objects.filter(like_id=int(course_id), like_type=2, like_status=True, like_man=request.user)
            if like:
                likecourse = True
            like1 = UserLike.objects.filter(like_id=int(course_id), like_type=1, like_status=True, like_man=request.user)
            if like1:
                likeorg = True

        return render(request, 'courses/courses-detail.html', {
            'course': course,
            'relate_course': relate_courses,
            'likecourse': likecourse,
            'likeorg': likeorg
        })


def course_video(request, course_id):
    if course_id:
        course = CourseInfo.objects.filter(id=int(course_id))[0]

        usercourse_list = UserCourse.objects.filter(study_man=request.user, study_course=course)
        if usercourse_list:
            a = UserCourse()
            a.study_man = request.user
            a.study_course = course
            a.save()
            course.study_num += 1
            course.save()

            usercourse_list = UserCourse.objects.filter(study_man=request.user)
            course_list = [usercourse.study_course for usercourse in usercourse_list]

            org_list = list(set([course.orginfo for course in course_list]))

            if course.orginfo not in org_list:
                course.orginfo.study_num += 1
                course.orginfo.save()

        usercourse_list = UserCourse.objects.filter(study_course=course)

        user_list = [usercourse.study_man for usercourse in usercourse_list]

        usercourse_list = UserCourse.objects.filter(study_man__in=user_list)

        course_list  =list(set([usercourse.study_course for usercourse in usercourse_list]))


        return render(request, 'courses/course-video.html', {
            'course': course
        })


def course_comment(request, course_id):
    if course_id:
        course = CourseInfo.objects.filter(id=int(course_id)[0])
        all_comments = course.usercomment_set.all()

        return render(request, 'courses/course-comment.html',{
            'course': course,
            'all_comments': all_comments
        })