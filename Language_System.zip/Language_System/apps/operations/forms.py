from django import forms
from .models import UserAsk
import re


class UserAskForm(forms.ModelForm):
    class Meta:
        model = UserAsk
        fields = ['name', 'course', 'phone']
        # exclude = ['add_time']
        # fields = '__all__'

    def clean_phone(self):
        phone = self.cleaned_data['phone']
        com = re.compile('^1([358][0-9][4[579]|66|7[0135678]|9[89])[0-9]]{8}$')
        if com.match(phone):
            return phone
        else:
            raise forms.ValidationError('Invalid phone number')


class UserCommentForm(forms.Form):
    course = forms.IntegerField(request=True)
    content = forms.CharField(request=True, min_length=1, max_length=300)

