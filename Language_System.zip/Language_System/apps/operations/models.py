from datetime import datetime
from users.models import UserProfile
from django.db import models
from courses.models import CourseInfo


# Create your models here.
class UserAsk(models.Model):
    name = models.CharField(max_length=30, verbose_name="User Name")
    phone = models.CharField(max_length=11, verbose_name="Phone Number")
    course = models.CharField(max_length=20, verbose_name="Course")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Consulting Information"
        verbose_name_plural = verbose_name


class UserLike(models.Model):
    like_man = models.ForeignKey(UserProfile, verbose_name="Collect User", on_delete=models.CASCADE, )
    like_id = models.IntegerField(verbose_name="Collection ID")
    like_type = models.IntegerField(choices=((1, 'Organization'), (2, 'Course'), (3, 'Teacher')),
                                    verbose_name="Collection Type")
    like_status = models.BooleanField(default=False, verbose_name="Collect Status")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.like_man.username

    class Meta:
        verbose_name = "Collection Information"
        verbose_name_plural = verbose_name


class UserCourse(models.Model):
    study_man = models.ForeignKey(UserProfile, verbose_name="Studying User", on_delete=models.CASCADE, )
    study_course = models.ForeignKey(CourseInfo, verbose_name="Studying Course", on_delete=models.CASCADE, )
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.study_man.username

    class Meta:
        unique_together = ('study_man', 'study_course')
        verbose_name = "User Course Information"
        verbose_name_plural = verbose_name


class UserComment(models.Model):
    comment_man = models.ForeignKey(UserProfile, verbose_name="Commenting User", on_delete=models.CASCADE, )
    comment_course = models.ForeignKey(CourseInfo, verbose_name="Commenting Course", on_delete=models.CASCADE, )
    comment_content = models.CharField(max_length=300, verbose_name="Comment Content")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Comment Time")

    def __str__(self):
        return self.comment_content

    class Meta:
        verbose_name = "User Comment Information"
        verbose_name_plural = verbose_name


class UserMessage(models.Model):
    message_man = models.IntegerField(default=0, verbose_name="Message User")
    message_content = models.CharField(max_length=200, verbose_name="Message Content")
    message_status = models.BooleanField(default=False, verbose_name="Message Status")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Comment Time")

    def __str__(self):
        return self.message_content

    class Meta:
        verbose_name = "User Message Information"
        verbose_name_plural = verbose_name
