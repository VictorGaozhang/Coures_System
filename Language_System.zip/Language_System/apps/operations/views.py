from django.shortcuts import render
from .forms import UserAskForm, UserCommentForm
from .models import UserAsk, UserLike, UserComment
from orgs.models import OrgInfo, TeacherInfo
from courses.models import CourseInfo
from django.http import JsonResponse


# Create your views here.
def user_ask(request):
    user_ask_form = UserAskForm(request.POST)
    if user_ask_form.is_valid():
        user_ask_form.save(commit=True)
        # name = user_ask_form.cleaned_data['name']
        # phone = user_ask_form.cleaned_data['phone']
        # course = user_ask_form.cleaned_data['course']
        #
        # a = UserAsk()
        # a.name = name
        # a.phone = phone
        # a.course = course
        # a.save()
        return JsonResponse({'status': 'ok', 'msg': "consulting successfully"})
    else:
        return JsonResponse({'status': 'fail', 'msg': "consulting failed"})


def user_like(request):
    likeid = request.GET.get('likeid', '')
    liketype = request.GET.get('liketype', '')
    if likeid and liketype:
        obj = None
        if int(liketype) == 1:
            obj = OrgInfo.objects.filter(id = int(likeid))[0]
        if int(liketype) == 2:
            obj = CourseInfo.objects.filter(id=int(likeid))[0]
        if int(liketype) == 3:
            obj = TeacherInfo.objects.filter(id=int(likeid))[0]

        like = UserLike.objects.filter(like_id=int(likeid), like_type=int(liketype), like_man=request.user)
        if like:
            if like[0].like_status:
                like[0].like_status = False
                like[0].save()
                obj.like_num -= 1
                obj.save()
                return JsonResponse({'status': 'ok', 'msg': "Collection"})

            else:
                like[0].like_status = True
                like[0].save()
                obj.like_num += 1
                obj.save()
                return JsonResponse({'status': 'ok', 'msg': "Collection canceled"})
        else:
            a = UserLike()
            a.like_man = request.user
            a.like_id = int(likeid)
            a.like_type = int(liketype)
            a.like_status = True
            a.save()
            return JsonResponse({'status': 'ok', 'msg': "Collection canceled"})
    else:
        return JsonResponse({'status': 'ok', 'msg': "Collection failed"})


def user_comment(request):
    user_comment_from = UserCommentForm(request.POST)
    if user_comment_from.is_valid():
        course = user_comment_from.cleaned_data['course']
        content = user_comment_from.cleaned_data['content']
        a = UserComment()
        a.comment_man = request.user
        a.comment_content = content
        a.comment_course_id = course
        a.save()
        return JsonResponse({'status': 'ok', 'msg': 'Comment Succeed'})
    else:
        return


def user_deletelike(request):
    likeid = request.GET.get('like', '')
    liketype = request.GET.get('liketype', '')
    if likeid and liketype:
        like = UserLike.objects.filter(like_id=int(likeid), like_type=int(liketype), like_man=request.user, like_status=True)
        if like:
            like[0].like_status = False
            like[0].save()
            return JsonResponse({'status': 'ok', 'msg': 'Cancel succeed'})
        else:
            return JsonResponse({'status': 'ok', 'msg': 'Cancel failed'})
    else:
        return JsonResponse({'status': 'ok', 'msg': 'Cancel failed'})