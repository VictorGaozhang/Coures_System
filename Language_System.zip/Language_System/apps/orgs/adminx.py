import xadmin
from .models import *


class CityInforXadmin(object):
    list_display = ['name', 'add_time']
    model_icon = 'fa fa-user'


class OrgInfoXadmin(object):
    list_display = ['image', 'name', 'course_num', 'study_num', 'address', 'detail',
                    'collect_num', 'click_num', 'category', 'city_info', 'add_time']
    model_icon = 'fa fa-user'


class TeacherInfoXadmin(object):
    list_display = ['image', 'name', 'work_year', 'work_position', 'work_style', 'work_company',
                    'age', 'gender', 'like_num', 'click_num', 'add_time']
    model_icon = 'fa fa-gift'


xadmin.site.register(CityInfor, CityInforXadmin)
xadmin.site.register(OrgInfo, OrgInfoXadmin)
xadmin.site.register(TeacherInfo, TeacherInfoXadmin)
