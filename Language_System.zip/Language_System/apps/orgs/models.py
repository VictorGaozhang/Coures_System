from datetime import datetime

from django.db import models


# Create your models here.
class CityInfor(models.Model):
    name = models.CharField(max_length=20, verbose_name="City Name")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "City Information"
        verbose_name_plural = verbose_name


class OrgInfo(models.Model):
    image = models.ImageField(upload_to='org/', max_length=200, verbose_name="Organization Image")
    name = models.CharField(max_length=20, verbose_name="Organization Name")
    course_num = models.IntegerField(default=0, verbose_name="Courses Number")
    study_num = models.IntegerField(default=0, verbose_name="Studying Number")
    address = models.CharField(max_length=200, verbose_name="Organization Location")
    detail = models.TextField(verbose_name="Organization Details")
    collect_num = models.IntegerField(default=0, verbose_name="Collection Number")
    click_num = models.IntegerField(default=0, verbose_name="Visits Number")
    category = models.CharField(choices=(('jg', 'learning institution'), ('gx', 'University'), ('gr', 'Person')),
                                max_length=10, verbose_name="Organization Type")
    city_info = models.ForeignKey(CityInfor, verbose_name="City", on_delete=models.CASCADE,)
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Organization Information"
        verbose_name_plural = verbose_name


class TeacherInfo(models.Model):
    image = models.ImageField(upload_to='teacher/', max_length=200, verbose_name="Teacher Image")
    name = models.CharField(max_length=20, verbose_name="Teacher Name")
    work_year = models.IntegerField(default=3, verbose_name="Working Years")
    work_position = models.CharField(max_length=20, verbose_name="Work Position")
    work_style = models.CharField(max_length=20, verbose_name="Teaching Style")
    work_company = models.ForeignKey(OrgInfo, verbose_name="Affiliation", on_delete=models.CASCADE,)
    age = models.IntegerField(default=30, verbose_name="Teacher Name")
    gender = models.CharField(choices=(('boy', 'male'), ('girl', 'female')), max_length=10,
                              verbose_name="Teacher Gender", default='boy')
    like_num = models.IntegerField(default=0, verbose_name="Collection Number")
    click_num = models.IntegerField(default=0, verbose_name="Visits Number")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Teacher Information"
        verbose_name_plural = verbose_name
