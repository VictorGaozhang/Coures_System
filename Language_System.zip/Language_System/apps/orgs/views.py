from django.shortcuts import render
from .models import OrgInfo, TeacherInfo, CityInfor
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from operations.models import UserLike

# Create your views here.
def org_list(request):
    all_orgs = OrgInfo.objects.all()
    all_citys = CityInfor.objects.all()
    sort_orgs = all_orgs.order_by('-love_num')[:3]

    # filter by orgs type
    cate = request.GET.get('cate', '')
    if cate:
        all_orgs = all_orgs.filter(category=cate)

    # filter by city
    cityid = request.GET.get('cityid', '')
    if cityid:
        all_orgs = all_orgs.filter(cityinfo_id=int(cityid))

    # sort
    sort = request.GET.get('sort', '')
    if sort:
        all_orgs = all_orgs.order_by('-'+sort)

    pagenum = request.GET.get('pagenum', '')
    pa = Paginator(all_orgs, 3)
    try:
        pages = pa.page(pagenum)
    except PageNotAnInteger:
        pages = pa.page(1)
    except EmptyPage:
        pages = pa.page(pa.num_pages)


    return render(request, 'orgs/org-list.html', {
        'all_orgs': all_orgs,
        'pages': pages,
        'all_citys': all_citys,
        'sort_orgs': sort_orgs,
        'cate': cate,
        'cityid': cityid,
        'sort': sort
    })

def org_detail(request, org_id):
    if org_id:
        org = OrgInfo.objects.filter(id=int(org_id))[0]
        org.click_num += 1
        org.save()


def org_detail(request, org_id):
    if org_id:
        org = OrgInfo.objects.filter(id=int(org_id))[0]

        likestates = False
        if request.user.is_authenticated():
            like = UserLike.objects.filter(like_man=request.user, like_id=int(org_id), like_type=1, like_status=True)
            if like:
                likestates = True

        return render(request, 'orgs/org-detail_homepage.html', {
            'org': org,
            'detail_type': 'home',
            'likestatus': likestates
        })


def org_detail_course(request, org_id):
    if org_id:
        org = OrgInfo.objects.filter(id = int(org_id))[0]
        all_courses = org.courseinfo_set.all()
        pagenum = request.GET.get('pagenum', '')
        pa = Paginator(all_courses, 2)
        try:
            pages = pa.page(pagenum)
        except PageNotAnInteger:
            pages = pa.page(1)
        except EmptyPage:
            pages = pa.page(pa.num_pages)
        return render(request, 'orgs/org-detail-course.html', {
            'org': org,
            'pages': pages,
            'detail_type': 'course',
        })


def org_detail_desc(request, org_id):
    if org_id:
        org = OrgInfo.objects.filter(id = int(org_id))[0]

        likestatus = False
        if request.user.is_authenticated():
            like = UserLike.objects.filter(like_man=request.user, like_id=int(org_id), like_type=1, like_status=True)
            if like:
                likestatus = True

        return render(request, 'orgs/org-detail-desc.html', {
            'org': org,
            'detail_type': 'desc',
            'likestatus': likestatus
        })


def org_detail_teacher(request, org_id):
    if org_id:
        org = OrgInfo.objects.filter(id = int(org_id))[0]

        likestatus = False
        if request.user.is_authenticated():
            like = UserLike.objects.filter(like_man=request.user, like_id=int(org_id), like_type=1, like_status=True)
            if like:
                likestatus = True

        return render(request, 'orgs/org-detail-teacher.html', {
            'org': org,
            'detail_type': 'teacher',
            'likestatus': likestatus
        })


def teacher_list(request):
    all_teacher = TeacherInfo.objects.all()
    sort_teachers = all_teacher.order_by('like-num')[:2]

    sort = request.GET.get('sort', '')
    if sort:
        all_teacher = all_teacher.order_by('-'+sort)

    pagenum = request.GET.get('pagenum', '')
    pa = Paginator(all_teacher, 2)
    try:
        pages = pa.page(pagenum)
    except PageNotAnInteger:
        pages = pa.page(1)
    except EmptyPage:
        pages = pa.page(pa.num_pages)

    return render(request, 'teacher-detail.html', {
        'all_teacher': all_teacher,
        'sort_teachers': sort_teachers,
        'pages': pages,
        'sort': sort
    })


def teacher_detail(request, teacher_id):
    if teacher_id:
        all_teacher = TeacherInfo.objects.all()
        teacher = TeacherInfo.objects.filter(id=int(teacher_id))[0]
        sort_teachers = all_teacher.order_by('-like_num')[:2]

        liketeacher = False
        likeorg = False
        if request.user.is_authenticated():
            like = UserLike.objects.filter(like_id=int(teacher_id), like_type=3, like_status=True, like_man=request.user)
            if like:
                liketeacher = True
            like1 = UserLike.objects.filter(like_id=teacher.work_company.id, like_type=1, like_status=True,
                                            like_man=request.user)
            if like1:
                likeorg = True

        return render(request, 'orgs/teacher-detail.html',{
            'teacher': teacher,
            'sort_teachers': sort_teachers,
            'liketeacher': liketeacher,
            'likeorg': likeorg
        })
