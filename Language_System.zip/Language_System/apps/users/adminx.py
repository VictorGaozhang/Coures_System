import xadmin
from .models import BannerInfor, EmailVerifyCode
from xadmin import views


class BaseXadminSetting(object):
    enable_themes = True
    use_bootswatch = True

class CommXadminSetting(object):
    site_title = 'Learning System - frontend'
    site_footer = "Learning System"
    menu_style = 'accordion'


class BannerInforXadmin(object):
    list_display = ['image', 'url', 'add_time']
    search_field = ['image', 'url']
    list_filter = ['image', 'url']


class EmailVerifyCodeXadmin(object):
    list_display = ['code', 'email', 'send_type', 'add_time']



xadmin.site.register(BannerInfor, BannerInforXadmin)
xadmin.site.register(EmailVerifyCode, EmailVerifyCodeXadmin)
xadmin.site.register(views.BaseAdminView, BaseXadminSetting)
xadmin.site.register(views.CommAdminView, CommXadminSetting)
