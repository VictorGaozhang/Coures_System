from django import forms
from captcha.fields import CaptchaField

from users.models import UserProfile, EmailVerifyCode


class UserRegisterForm(forms.Form):
    email = forms.EmailField(required=True)
    password = forms.CharField(required=True, min_length=3, max_length=15, error_messages={
        'required': 'Password needed',
        'min_length': 'At least 3 characters',
        'max_length': 'Less than 15 characters'
    })
    captcha = CaptchaField()


class UserLoginForm(forms.Form):
    username = forms.EmailField(required=True)
    password = forms.CharField(required=True, min_length=3, max_length=15, error_messages={
        'required': 'Password needed',
        'min_length': 'At least 3 characters',
        'max_length': 'Less than 15 characters'
    })


class UserForgetForm(forms.Form):
    username = forms.EmailField(required=True)
    password = forms.CharField(required=True, min_length=3, max_length=15, error_messages={
        'required': 'Password needed',
        'min_length': 'At least 3 characters',
        'max_length': 'Less than 15 characters'
    })


class UserResetForm(forms.Form):
    password = forms.CharField(required=True, min_length=3, max_length=15, error_messages={
        'required': 'Password needed',
        'min_length': 'At least 3 characters',
        'max_length': 'Less than 15 characters'
    })
    password1 = forms.CharField(required=True, min_length=3, max_length=15, error_messages={
        'required': 'Password needed',
        'min_length': 'At least 3 characters',
        'max_length': 'Less than 15 characters'
    })


class UserChangeImageForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['image']


class UserChangeInfoForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['nick_name', 'gender', 'address', 'phone', 'birthday']


class UserChangeEmailForm(forms.ModelForm):
    class Meta:
        model = EmailVerifyCode
        fields = ['email']


class UserResetEmailForm(forms.ModelForm):
    class Meta:
        model = EmailVerifyCode
        fields = ['email', 'code']