from datetime import datetime

from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class UserProfile(AbstractUser):
    image = models.ImageField(upload_to='user/', max_length=200, verbose_name="User Profile", null=True, blank=True)
    nick_name = models.CharField(max_length=20, verbose_name="Nick Name", null=True, blank=True)
    birthday = models.DateTimeField(verbose_name="User Birthday", null=True, blank=True)
    gender = models.CharField(choices=(('girl', 'female'), ('boy', 'male')), max_length=10, verbose_name="User Gender",
                              default='girl')
    address = models.CharField(max_length=200, verbose_name="User Address", null=True, blank=True)
    phone = models.CharField(max_length=11, verbose_name="User Phone", null=True, blank=True)
    is_start = models.BooleanField(default=False, verbose_name="Active or Not")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.username

    def get_msg_counter(self):
        from operations.models import UserMessage
        counter = UserMessage.objects.filter(self.id, message_status=False).count()
        return counter

    class Meta:
        verbose_name = 'User Information'
        verbose_name_plural = verbose_name


class BannerInfor(models.Model):
    image = models.ImageField(upload_to='banner/', verbose_name="Transfer Image", max_length=200)
    url = models.URLField(default='http://www.google.com', max_length=200, verbose_name="Pictures URL")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return str(self.image)

    class Meta:
        verbose_name = 'Transfer Image Information'
        verbose_name_plural = verbose_name


class EmailVerifyCode(models.Model):
    code = models.CharField(max_length=20, verbose_name="Email Verify Code")
    email = models.EmailField(max_length=200, verbose_name="Verify Code Email")
    send_type = models.IntegerField(choices=((1, 'register'), (2, 'forget'), (3, 'change')),
                                    verbose_name="Verify Code Type")
    add_time = models.DateTimeField(default=datetime.now, verbose_name="Adding Time")

    def __str__(self):
        return self.code

    class Meta:
        verbose_name = 'Email Verify Code Information'
        verbose_name_plural = verbose_name
