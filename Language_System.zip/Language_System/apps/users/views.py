from django.contrib.auth import logout, login
from django.db.models.functions import datetime
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect, reverse
from .forms import UserRegisterForm, UserLoginForm, UserForgetForm, UserResetForm, UserChangeImageForm, \
    UserChangeInfoForm, UserChangeEmailForm, UserResetEmailForm
from .models import UserProfile, EmailVerifyCode, BannerInfor
from django.db.models import Q
from django.core.mail import send_mail
from tools.send_mail_tool import send_email_code
from datetime import datetime
from operations.models import UserLike, UserMessage
from orgs.models import OrgInfo, TeacherInfo
from courses.models import CourseInfo


# Create your views here.
def index(request):
    all_banners = BannerInfor.objects.all().order_by("-add_time")[:5]
    banners_courses = CourseInfo.objects.filter(is_banner=True)[:3]
    all_courses = BannerInfor.objects.filter(is_banner=False)[:6]
    all_orgs = OrgInfo.objects.all()[:15]
    return render(request, 'user/index.html', {
        'all_banners': all_banners,
        'banner_courses': banners_courses,
        'all_courses': all_courses,
        'all_orgs': all_orgs
    })


def user_register(request):
    if request.method == 'GET':
        user_register_form = UserRegisterForm(request.POST)
        return render(request, 'user/register.html')
    else:
        user_register_form = UserRegisterForm(request.POST)
        if user_register_form.is_valid():
            email = user_register_form.cleaned_data['email']
            password = user_register_form.cleaned_data['password']

            user_list = UserProfile.objects.filter(Q(username=email) | Q(email=email))
            if user_list:
                return render(request, 'user/register.html', {
                    'msg': 'User exist already'
                })
            else:
                a = UserProfile()
                a.username = email
                a.set_password(password)
                a.email = email
                a.save()
                send_email_code(email, 1)
                return HttpResponse('Please active your email')
                # return redirect(reverse('index'))
        else:
            return render(request, 'user/register.html', {
                'user_register_form': user_register_form
            })


def user_login(request):
    if request.method == 'GET':
        return render(request, 'user/login.html')
    else:
        user_login_form = UserLoginForm(request.POST)
        if user_login_form.is_valid():
            username = user_login_form.cleaned_data['username']
            password = user_login_form.cleaned_data['password']

            user = UserProfile.objects.filter(Q(username=username) | Q(email=password))
            if user:
                if user.is_start:
                    login(request, user)
                    return redirect(reversed('index'))
                else:
                    return HttpResponse("Please active your email address")
            else:
                return render(request, 'user/login.html')
        else:
            return render(request, 'user/register.html', {
                'user_register_form': user_login_form
            })


def user_logout(request):
    logout(request)
    return redirect(reverse('index'))


def user_active(request, code):
    if code:
        email_ver_list = EmailVerifyCode.filter(code=code)
        if email_ver_list:
            email_ver = email_ver_list[0]
            email = email_ver.email
            user_list = UserProfile.objects.filter(username=email)
            if user_list:
                user = user_list[0]
                user.is_start = True
                user.save()
                return redirect(reverse('user:user_login'))
            else:
                pass
        else:
            pass
    else:
        pass


def user_forget(request):
    if request.method == "GET":
        user_forget_form = UserForgetForm()
        return render(request, 'user/forgetpwd.html', {
            'user_forget_form':user_forget_form
        })
    else:
        user_forget_form = UserForgetForm(request.POST)
        if user_forget_form.is_valid():
            email = user_forget_form.cleaned_data['email']
            user_list = UserProfile.objects.filter(email=email)
            if user_list:
                send_email_code(email, 2)
                return HttpResponse('Please go to your email address to reset password')
            else:
                return render(request, 'user/forgetpwd.html', {
                    'msg': "User doesn't exist"
                })
        else:
            return render(request, 'user/forgetpwd.html', {
                'user_forget_form': user_forget_form
            })

def user_reset(request, code):
    if code:
        if request.method == 'GET':
            return render(request, 'user/password_reset.html', {
                'code': code
            })
        else:
            user_reset_form = UserResetForm(request.POST)
            if user_reset_form.is_valid()():
                password = user_reset_form.cleaned_data['password']
                password1 = user_reset_form.cleaned_data['password1']
                if password == password1:
                    email_ver_list = EmailVerifyCode.objects.filter(code=code)
                    if email_ver_list:
                        email_ver = email_ver_list[0]
                        email = email_ver.email
                        user_list = UserProfile.objects.filter(email=email)
                        if user_list:
                            user = user_list[0]
                            user.set_password(password1)
                            user.save()
                            return redirect(reverse('user:user_login'))
                        else:
                            pass
                    else:
                        pass
                else:
                    return render(request, 'user/password_reset.html', {
                        'msg': 'Different password',
                        'code': code
                    })
            else:
                return render(request, 'user/password_reset.html', {
                    'user_reset_form': user_reset_form,
                    'code': code
                })


def user_info(request):
    return render(request, 'users/usercenter-info.html')


def user_changeimage(request):
    user_changeimage_form = UserChangeImageForm(request.POST, request.FILES, instance=request.user)
    if user_changeimage_form.is_valid():
        user_changeimage_form.save(commit=True)
        return JsonResponse({'status': 'ok'})
    else:
        return JsonResponse({'status': 'fail'})


def user_changeinfo(request):
    user_changeinfo_form = UserChangeInfoForm(request.POST, instance=request.user)
    if user_changeinfo_form.is_valid():
        user_changeinfo_form.save(commit=True)
        return JsonResponse({'status': 'ok', 'msg': 'Modifying Succeed'})
    else:
        return JsonResponse({'status': 'ok', 'msg': 'Modifying Failed'})


def user_changeemail(request):
    """

    :param request: http request
    :return: return json data
    """
    user_changeemail_form = UserChangeEmailForm(request.POST)
    if user_changeemail_form.is_valid():
        email = user_changeemail_form.cleaned_data['email']
        user_list = UserProfile.objects.filter(Q(email=email)|Q(username=email))
        if user_list:
            return JsonResponse({'status': 'fail', 'msg': 'Email has been bound'})
        else:
            email_ver_list = EmailVerifyCode.objects.filter(email=email, send_type=3)
            send_email_code(email, 3)
            return JsonResponse({'status': 'fail', 'msg': 'Please check verification code in email'})
    else:
        return JsonResponse({'status': 'fail', 'msg': 'Something problem about your email address'})


def user_resetemail(request):
    user_resetemail_form = UserResetEmailForm(request.POST)
    if user_resetemail_form.is_valid():
        email = user_resetemail_form.cleaned_data['email']
        code = user_resetemail_form.cleaned_data['code']

        email_ver_list = EmailVerifyCode.objects.filter(email=email, code=code)
        if email_ver_list:
            email_ver = email_ver_list[0]
            if(datetime.now() - email_ver.add_time).seconds < 60:
                request.user.username = email
                request.user.email = email
                request.user.save()
                return JsonResponse({'status': 'ok', 'msg': 'Email modifying succeed'})
            else:
                return JsonResponse({'status': 'ok', 'msg': 'verification code out of time'})
        else:
            return JsonResponse({'status': 'ok', 'msg': 'verification code error'})
    else:
        return JsonResponse({'status': 'ok', 'msg': 'verification code illegal'})


def user_course(request):
    usercourse_list = request.user.usercourse_set.all()
    course_list = [usercourse.study_course for usercourse in usercourse_list]

    return render(request, 'user/usercenter-mycourse.html', {
        'course_list':course_list
    })


def user_likeorg(request):
    # userlikeorg_list = request.user.userlike_set.all().filter(like_type=1)
    userlikeorg_list = UserLike.objects.filter(like_man=request.user, like_type=1, like_status=True)
    org_ids = {userlikeorg.like_id for userlikeorg in userlikeorg_list}
    org_list = OrgInfo.objects.filter(id_in=org_ids)

    return render(request, 'users/usercenter-fav-org.html', {
        'org_list': org_list
    })


def user_liketeacher(request, userliketeacher_list=None):
    # userlikeorg_list = request.user.userlike_set.all().filter(like_type=1)
    userlikeTeacher_list = UserLike.objects.filter(like_man=request.user, like_type=3, like_status=True)
    teacher_ids = [userliketeacher.like_id for userliketeacher in userliketeacher_list]
    teacher_list = TeacherInfo.objects.filter(id_in=teacher_ids)

    return render(request, 'users/usercenter-fav-teacher.html', {
        'teacher_list': teacher_list
    })

def user_likecourse(request):
    # userlikeorg_list = request.user.userlike_set.all().filter(like_type=1)
    userlikecourse_list = UserLike.objects.filter(like_man=request.user, like_type=1, like_status=True)
    course_ids = [userlikecourse.like_id for userlikecourse in userlikecourse_list]
    course_list = CourseInfo.objects.filter(id_in=course_ids)

    return render(request, 'users/usercenter-fav-course.html', {
        'course_list': course_list
    })


def user_message(request):
    msg_list = UserMessage.objects.filter(message_man=request.user.id)
    return render(request, 'users/usercenter-message.html', {
        'msg_list': msg_list
    })


def user_deletemessage(request):
    delete_id = request.GET.get('delete_id', '')
    if delete_id:
        msg = UserMessage.objects.filter(id=int(delete_id))[0]
        msg.message_status = True
        msg.save()
        return JsonResponse({'status': 'ok', 'msg': 'Seen'})
    else:
        return JsonResponse({'status': 'fail', 'msg': 'Reading failed'})