from users.models import EmailVerifyCode
from random import choice
from random import randrange
from django.core.mail import send_mail
from Language_System.settings import EMAIL_FROM


def get_random_code(code_length):
    code_source = '1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'
    code = ''
    for i in range(code_length):
        str = code_source[randrange(0, len(code_source)-1)]
        code += str
        # code += choice(code_source)
    return code


def send_email_code(email, send_type):
    code = get_random_code(8)
    a = EmailVerifyCode()
    a.email = email
    a.send_type = send_type
    a.code = code
    a.save()

    send_title = ''
    send_body = ''
    if send_type == 1:
        send_title = 'Welcome submitting: '
        send_body = 'Please click the link below for active: \n http://127.0.0.1:8000/users/user_active' +code
        send_mail(send_title, send_body, EMAIL_FROM, [email])

    if send_type == 2:
        send_title = 'Resetting system: '
        send_body = 'Please click the link below for resetting: \n http://127.0.0.1:8000/users/user_active' + code
        send_mail(send_title, send_body, EMAIL_FROM, [email])

    if send_type == 2:
        send_title = 'Modifying email verification code: '
        send_body = 'Please click the link below for resetting: \n http://127.0.0.1:8000/users/user_active' + code
        send_mail(send_title, send_body, EMAIL_FROM, [email])
